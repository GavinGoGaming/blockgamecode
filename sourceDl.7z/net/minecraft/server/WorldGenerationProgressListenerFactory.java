/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.server;

import net.minecraft.server.WorldGenerationProgressListener;

public interface WorldGenerationProgressListenerFactory {
    public WorldGenerationProgressListener create(int var1);
}

