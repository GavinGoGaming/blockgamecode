/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.network.handler;

import io.netty.channel.ChannelOutboundHandlerAdapter;

public class NoopOutboundHandler
extends ChannelOutboundHandlerAdapter {
}

