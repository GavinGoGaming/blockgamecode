/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.network.handler;

import io.netty.handler.codec.EncoderException;

public class PacketEncoderException
extends EncoderException {
    public PacketEncoderException(Throwable cause) {
        super(cause);
    }
}

