/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.network.packet.c2s.login;

import net.minecraft.network.PacketByteBuf;

public interface LoginQueryResponsePayload {
    public void write(PacketByteBuf var1);
}

