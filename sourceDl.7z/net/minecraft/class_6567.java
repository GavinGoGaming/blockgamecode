/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft;

public class class_6567 {
    public static final double field_34584 = 0.0;
    public static final double field_34585 = 64.0;
    public static final double field_34586 = -64.0;
}

