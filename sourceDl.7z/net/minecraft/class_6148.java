/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft;

public class class_6148 {
    public static final int field_31827 = 0;
    public static final int field_31828 = 15;
    public static final int field_31829 = 0;
}

